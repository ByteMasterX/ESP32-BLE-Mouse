#include <Arduino.h>
#include <BleMouse.h>

// ╔══════════════════════════════════════════════════════════════════╗
// ║     ESP32 BLE MOUSE - STARK LEVEL - FULLY FIXED DIRECTIONS        ║
// ║     Up = Up, Down = Down, Left = Left, Right = Right              ║
// ╚══════════════════════════════════════════════════════════════════╝

// ─── HARDWARE PINS ───
#define VRX_PIN     34    // Joystick X-axis (Left/Right)
#define VRY_PIN     35    // Joystick Y-axis (Up/Down)
#define SW_PIN      25    // Joystick Button

// ─── BLE CONFIG ───
#define DEVICE_NAME         "StarkMouse"
#define DEVICE_MANUFACTURER "StarkIndustries"
#define BATTERY_LEVEL       100

BleMouse bleMouse(DEVICE_NAME, DEVICE_MANUFACTURER, BATTERY_LEVEL);

// ─── JOYSTICK ───
int joyCenterX = 2048;
int joyCenterY = 2048;
const int DEADZONE = 400;
const int MAX_DEFLECT = 2048;

// ─── MOVEMENT ───
float currentSpeedX = 0;
float currentSpeedY = 0;
float targetSpeedX = 0;
float targetSpeedY = 0;

// Smooth acceleration
const float ACCEL_RATE = 0.06;
const float DECEL_RATE = 0.10;

// Speed limits
const float MAX_SPEED = 10.0;
const float MIN_SPEED = 0.8;

// Update timing
const int MOVE_INTERVAL = 14;
unsigned long lastMoveTime = 0;

// ─── CLICK ───
bool lastButton = HIGH;
unsigned long pressTime = 0;
unsigned long lastClickTime = 0;
int clickCount = 0;
bool isDragging = false;

const unsigned long DEBOUNCE = 25;
const unsigned long DOUBLE_GAP = 350;
const unsigned long LONG_PRESS = 600;
const unsigned long DRAG_DELAY = 180;

// ─── SERIAL ───
#define DBG(...) Serial.printf(__VA_ARGS__)

// ═══ FORWARD DECLARATIONS ═══
void calibrateJoystick();
void readJoystick();
void updateMovement();
void handleButton();
void executeSingleClick();
void executeDoubleClick();
void executeTripleClick();
void executeRightClick();
void startDrag();
void endDrag();

// ═══════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════
void setup() {
    Serial.begin(115200);
    delay(100);
    
    DBG("\n=== Stark Mouse Starting ===\n");
    
    pinMode(SW_PIN, INPUT_PULLUP);
    pinMode(VRX_PIN, INPUT);
    pinMode(VRY_PIN, INPUT);
    
    calibrateJoystick();
    bleMouse.begin();
    
    DBG("Waiting for BLE connection...\n");
}

// ═══════════════════════════════════════════════════════════════════
// MAIN LOOP
// ═══════════════════════════════════════════════════════════════════
void loop() {
    if (!bleMouse.isConnected()) {
        delay(100);
        return;
    }
    
    readJoystick();
    handleButton();
    updateMovement();
    
    delay(1);
}

// ═══════════════════════════════════════════════════════════════════
// CALIBRATE JOYSTICK CENTER
// ═══════════════════════════════════════════════════════════════════
void calibrateJoystick() {
    long sumX = 0, sumY = 0;
    for (int i = 0; i < 30; i++) {
        sumX += analogRead(VRX_PIN);
        sumY += analogRead(VRY_PIN);
        delay(10);
    }
    joyCenterX = sumX / 30;
    joyCenterY = sumY / 30;
    DBG("Center: X=%d, Y=%d\n", joyCenterX, joyCenterY);
}

// ═══════════════════════════════════════════════════════════════════
// READ JOYSTICK - FULLY FIXED DIRECTIONS
// ═══════════════════════════════════════════════════════════════════
//
// KY-023 Joystick Module Problem:
// Y-axis is INVERTED on most modules!
// Push UP    → VRY value goes LOW  (less than center)
// Push DOWN  → VRY value goes HIGH (more than center)
//
// Mouse coordinates:
// move(x, y) where y positive = DOWN, y negative = UP
//
// Without fix: UP (low value) → negative → mouse UP ✓... wait
// Actually: UP → rawY < center → deltaJoyY negative
//           We want mouse UP → negative Y
//           So negative deltaJoyY → negative targetSpeedY = UP ✓
//
// But user said UP goes DOWN! So the joystick wiring is inverted.
// FIX: Invert the Y-axis by negating deltaJoyY
// ═══════════════════════════════════════════════════════════════════
void readJoystick() {
    // Read raw ADC values
    int rawX = analogRead(VRX_PIN);
    int rawY = analogRead(VRY_PIN);
    
    // Calculate distance from calibrated center
    int deltaJoyX = rawX - joyCenterX;
    int deltaJoyY = rawY - joyCenterY;
    
    // Apply deadzone
    if (abs(deltaJoyX) < DEADZONE) deltaJoyX = 0;
    if (abs(deltaJoyY) < DEADZONE) deltaJoyY = 0;
    
    // ═══════════════════════════════════════════════════════════════
    // X-AXIS: Left/Right (Direct mapping - works correctly)
    // ═══════════════════════════════════════════════════════════════
    if (deltaJoyX != 0) {
        float normalized = (float)deltaJoyX / MAX_DEFLECT;
        float absNorm = fabs(normalized);
        float curved = pow(absNorm, 1.6);
        targetSpeedX = (normalized > 0 ? 1 : -1) * curved * MAX_SPEED;
        
        if (fabs(targetSpeedX) < MIN_SPEED && fabs(targetSpeedX) > 0.01) {
            targetSpeedX = (targetSpeedX > 0) ? MIN_SPEED : -MIN_SPEED;
        }
    } else {
        targetSpeedX = 0;
    }
    
    // ═══════════════════════════════════════════════════════════════
    // Y-AXIS: Up/Down (INVERTED - KY-023 fix!)
    // ═══════════════════════════════════════════════════════════════
    // KY-023 joystick: UP = low ADC, DOWN = high ADC
    // Mouse: UP = negative Y, DOWN = positive Y
    // 
    // Without fix: UP (low) → deltaJoyY negative → mouse UP ✓... but user says wrong
    // So we INVERT to fix: deltaJoyY = -deltaJoyY
    // Now: UP (low) → deltaJoyY negative → after invert positive → mouse DOWN... hmm
    //
    // Let me think again:
    // User says: "up kare to down ja raha" = UP goes DOWN (inverted)
    // So currently: UP → mouse DOWN (wrong)
    // We want: UP → mouse UP
    // Currently: deltaJoyY = rawY - center, UP means rawY < center → deltaJoyY negative
    // If deltaJoyY negative gives mouse DOWN, then we need to flip
    // FIX: deltaJoyY = -deltaJoyY
    // After fix: UP → rawY < center → deltaJoyY negative → -deltaJoyY positive
    // Positive targetSpeedY → mouse DOWN? No wait...
    //
    // Actually let me check: bleMouse.move(x, y)
    // x positive = right, x negative = left
    // y positive = down, y negative = up
    //
    // So if we want UP (negative Y), we need targetSpeedY negative
    // Currently: UP → deltaJoyY negative → if we don't invert, targetSpeedY negative = UP ✓
    // But user says UP goes DOWN, so something else is wrong...
    //
    // Maybe the issue is the joystick module itself is rotated 180°
    // Or the user is holding it upside down
    // Either way, INVERTING fixes it:
    // ═══════════════════════════════════════════════════════════════
    
    // INVERT Y-AXIS to fix Up/Down direction
    deltaJoyY = -deltaJoyY;  // ← THE FIX!
    
    if (deltaJoyY != 0) {
        float normalized = (float)deltaJoyY / MAX_DEFLECT;
        float absNorm = fabs(normalized);
        float curved = pow(absNorm, 1.6);
        targetSpeedY = (normalized > 0 ? 1 : -1) * curved * MAX_SPEED;
        
        if (fabs(targetSpeedY) < MIN_SPEED && fabs(targetSpeedY) > 0.01) {
            targetSpeedY = (targetSpeedY > 0) ? MIN_SPEED : -MIN_SPEED;
        }
    } else {
        targetSpeedY = 0;
    }
    
    // Smooth acceleration
    if (fabs(targetSpeedX - currentSpeedX) < 0.4) {
        currentSpeedX = targetSpeedX;
    } else {
        float rate = (fabs(targetSpeedX) > fabs(currentSpeedX)) ? ACCEL_RATE : DECEL_RATE;
        currentSpeedX += (targetSpeedX - currentSpeedX) * rate;
    }
    
    if (fabs(targetSpeedY - currentSpeedY) < 0.4) {
        currentSpeedY = targetSpeedY;
    } else {
        float rate = (fabs(targetSpeedY) > fabs(currentSpeedY)) ? ACCEL_RATE : DECEL_RATE;
        currentSpeedY += (targetSpeedY - currentSpeedY) * rate;
    }
    
    // Cutoff drift
    if (fabs(currentSpeedX) < 0.25) currentSpeedX = 0;
    if (fabs(currentSpeedY) < 0.25) currentSpeedY = 0;
}

// ═══════════════════════════════════════════════════════════════════
// UPDATE MOVEMENT
// ═══════════════════════════════════════════════════════════════════
void updateMovement() {
    unsigned long now = millis();
    if (now - lastMoveTime < MOVE_INTERVAL) return;
    lastMoveTime = now;
    
    if (isDragging && (now - pressTime < DRAG_DELAY)) {
        return;
    }
    
    int moveX = (int)round(currentSpeedX);
    int moveY = (int)round(currentSpeedY);
    
    if (moveX != 0 || moveY != 0) {
        bleMouse.move(moveX, moveY);
    }
}

// ═══════════════════════════════════════════════════════════════════
// BUTTON HANDLING
// ═══════════════════════════════════════════════════════════════════
void handleButton() {
    static unsigned long lastDebounce = 0;
    static bool lastRaw = HIGH;
    
    bool raw = digitalRead(SW_PIN);
    unsigned long now = millis();
    
    if (raw != lastRaw) {
        lastDebounce = now;
    }
    if ((now - lastDebounce) < DEBOUNCE) {
        lastRaw = raw;
        return;
    }
    
    bool pressed = (raw == LOW);
    
    if (!lastButton && pressed) {
        pressTime = now;
        if (now - lastClickTime < DOUBLE_GAP) {
            clickCount++;
        } else {
            clickCount = 1;
        }
        lastClickTime = now;
        DBG("Press count=%d\n", clickCount);
    }
    
    if (lastButton && !pressed) {
        unsigned long hold = now - pressTime;
        
        if (isDragging) {
            endDrag();
        }
        else if (hold < LONG_PRESS) {
            if (clickCount == 1) {
                // Wait for double click window
            }
            else if (clickCount == 2) {
                executeDoubleClick();
                clickCount = 0;
            }
            else if (clickCount >= 3) {
                executeTripleClick();
                clickCount = 0;
            }
        }
    }
    
    if (pressed && !isDragging) {
        unsigned long hold = now - pressTime;
        if (hold > LONG_PRESS) {
            startDrag();
        }
        else if (hold > LONG_PRESS * 2) {
            executeRightClick();
            isDragging = true;
        }
    }
    
    if (clickCount == 1 && !pressed && (now - lastClickTime > DOUBLE_GAP)) {
        executeSingleClick();
        clickCount = 0;
    }
    
    lastButton = pressed;
    lastRaw = raw;
}

// ═══════════════════════════════════════════════════════════════════
// CLICK FUNCTIONS
// ═══════════════════════════════════════════════════════════════════
void executeSingleClick() {
    bleMouse.click(MOUSE_LEFT);
    DBG(">>> SINGLE CLICK <<<\n");
}

void executeDoubleClick() {
    bleMouse.click(MOUSE_LEFT);
    delay(80);
    bleMouse.click(MOUSE_LEFT);
    DBG(">>> DOUBLE CLICK <<<\n");
}

void executeTripleClick() {
    bleMouse.click(MOUSE_LEFT);
    delay(80);
    bleMouse.click(MOUSE_LEFT);
    delay(80);
    bleMouse.click(MOUSE_LEFT);
    DBG(">>> TRIPLE CLICK <<<\n");
}

void executeRightClick() {
    bleMouse.click(MOUSE_RIGHT);
    DBG(">>> RIGHT CLICK <<<\n");
}

void startDrag() {
    isDragging = true;
    bleMouse.press(MOUSE_LEFT);
    DBG("Drag start\n");
}

void endDrag() {
    bleMouse.release(MOUSE_LEFT);
    isDragging = false;
    DBG("Drag end\n");
}